#include "ex_lzw.h"
#include "ex_dict.h"

#include <string.h>
#include <stdbool.h>

#define DICT_LENGTH 65536

typedef unsigned char BYTE;

// INTERNAL FUNCTION PROTOTYPES

BYTE search(unsigned short int, BYTE **, unsigned short int, BYTE*, unsigned short int *, BYTE*);

// EXTERNAL FUNCTION DEFINITIONS

void EX_LZW_COMPRESS(FILE *in_fp, FILE *out_fp) {
	unsigned int count;
	unsigned short int number, prevLen, i, id, dictPtr;

	count   = 0;
	number  = 1;
	prevLen = 0;
	i       = 0;
	id      = 0;
	dictPtr = 0;

	BYTE curr, match, *prev, *concat, *wordLen, **dict;

	curr    = 0;
	match   = 0;
	wordLen = (BYTE *)malloc(DICT_LENGTH);    
	dict    = (BYTE **)malloc(DICT_LENGTH * sizeof(BYTE *));

	for (i=0; i<256; i++) {
		dict[i]    = (BYTE *)malloc(sizeof(BYTE));
		dict[i][0] = i;
		wordLen[i] = 1;
	}

	dictPtr = i-1;	
	prev = (BYTE *)malloc(1);

	while (number == 1) {
		number = fread(&curr, 1, 1, in_fp);
			if (number == 0)
				break;

		concat = (BYTE*)malloc(prevLen+1);

		if (prevLen > 0)
			memcpy(concat, prev, prevLen);

		memcpy((concat+prevLen), &curr, 1);
		match = search(dictPtr, dict, prevLen+1, concat, &id, wordLen);

		if (match == 1) {
			free(prev);
			prev = (BYTE*)malloc(prevLen+1);
			memcpy(prev, concat, prevLen+1);
			prevLen++;
		} else {
			if (prevLen > 0) {
				(void)search(dictPtr, dict, prevLen, prev, &id, wordLen);
				count += fwrite(&id, sizeof(unsigned short int), 1, out_fp);
				match = 0;
			}
			
			dictPtr++;
			wordLen[dictPtr] = prevLen + 1;
			dict[dictPtr] = (BYTE *)malloc((prevLen+1)*sizeof(BYTE));
			memcpy(dict[dictPtr], concat, prevLen+1);
			
			free(prev);
			prev = (BYTE*)malloc(1);
			*prev = curr;
			prevLen = 1;

		}
		free(concat);
		match = 0;
	}

	(void)search(dictPtr, dict, prevLen, prev, &id, wordLen);

	count += fwrite(&id, sizeof(unsigned short int), 1, out_fp);

	for(i=0; i<= dictPtr; i++)
		free(dict[i]);

	free(dict);
	free(wordLen);
}

void EX_LZW_DECOMPRESS(FILE *in_fp, FILE *out_fp) {
	unsigned int count = 0;
	unsigned short int curr, prev, number, i, dictPtr;

	curr    = 0;
	prev    = 0;
	number     = 1;
	i       = 0;
	dictPtr = 0;

	BYTE *X, Y, Z, *concat;
	BYTE *wordLen;
	BYTE **dict;

	wordLen = (BYTE *)malloc(DICT_LENGTH);
	dict    = (BYTE **)malloc(DICT_LENGTH * sizeof(BYTE *));

	for (i=0; i<256; i++) {
		dict[i] = (BYTE *)malloc(sizeof(BYTE));
		dict[i][0] = i;
		wordLen[i] = 1;
	}
	dictPtr = i-1;

	number = fread(&curr, sizeof(curr), 1, in_fp);
	fwrite(dict[curr], 1, 1, out_fp );

	while (number == 1) {
		prev = curr;
		number = fread(&curr, sizeof(curr), 1, in_fp);
		if (number == 0)
			break;

		X = (BYTE*)malloc(wordLen[prev]);
		memcpy(X, dict[prev], wordLen[prev]);

		concat = (BYTE*)malloc(wordLen[prev]+1);
		memcpy(concat, X, wordLen[prev]);

		if (curr <= dictPtr) {
			count += fwrite(dict[curr], 1, wordLen[curr], out_fp);
			Y = dict[curr][0];

			memcpy((concat+wordLen[prev]), &Y, 1);
			dictPtr++;
			wordLen[dictPtr] = wordLen[prev]+1;

			dict[dictPtr] = (BYTE *)malloc(wordLen[dictPtr]);
			memcpy(dict[dictPtr], concat, wordLen[dictPtr]);
		} else {
			Z = dict[prev][0];
			memcpy((concat+wordLen[prev]), &Z, 1);
			count += fwrite(concat, 1, wordLen[prev]+1, out_fp);

			dictPtr++;
			wordLen[dictPtr] = wordLen[prev]+1;

			dict[dictPtr] = (BYTE *)malloc(wordLen[dictPtr]);
			memcpy(dict[dictPtr], concat, wordLen[dictPtr]);
		}

		free(X);
		free(concat);
	}

	for(i=0; i<= dictPtr; i++)
		free(dict[i]);

	free(dict);
	free(wordLen);
}

// INTERNAL FUNCTION DEFINITIONS

BYTE search(unsigned short int dID, BYTE **dict, unsigned short int len, BYTE *prev, unsigned short int *id, BYTE *wordLen) {
    int i;
    BYTE match = 0;
    
    for(i=0; (i<= dID && match == 0); i++)
    {
        if(len == wordLen[i])
            if(0 == memcmp(prev, dict[i], len ))
            {
                match = 1;
                *id = i;
            }
    }

    return match;
}
