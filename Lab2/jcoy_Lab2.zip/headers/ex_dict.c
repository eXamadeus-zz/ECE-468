#include "ex_dict.h"

// INTERNAL FUNCTION PROTOTYPES

void __FREE_DICT_PAGE (EX_DICT_PAGE *);
void __FREE_DICT (EX_DICT *);

// EXTERNAL FUNCTION DEFINITIONS

EX_DICT * EX_DICT_INIT() {
	EX_DICT *dict;

	dict = (EX_DICT *)malloc(sizeof(EX_DICT));
	dict->count = 0;
	dict->head = NULL;
	dict->tail = NULL;

	EX_DICT_ADD_PAGE(dict);
	EX_DICT_ADD_PAGE(dict);

	dict->cursorPos = 0;

	return dict;
}

void EX_DICT_ADD_PAGE(EX_DICT *dict) {
	if (!dict) exit(3);
	
	unsigned char **elem;

	EX_DICT_PAGE *ptr;

	if (dict->tail == NULL) { // build first page
		ptr         = (EX_DICT_PAGE *)malloc(sizeof(EX_DICT_PAGE));
		dict->tail  = ptr;
		dict->head  = ptr;
		ptr->elem   = (unsigned char **)malloc(sizeof(unsigned char*)*256);
		ptr->next   = NULL;
		ptr->prev   = NULL;
		dict->count = 1;
		
		elem = ptr->elem;

		int i;

		for (i=0; i<256; i++) {
			elem[i] = malloc(sizeof(unsigned char));
			elem[i][0] = (unsigned char)i;
		}

	} else {
		ptr              = (EX_DICT_PAGE *)malloc(sizeof(EX_DICT_PAGE));
		dict->tail->next = ptr;
		ptr->prev        = dict->tail;
		ptr->next        = NULL;
		dict->tail       = ptr;
		dict->count++;
		ptr->elem        = (unsigned char **)malloc(sizeof(unsigned char*)*256);

		elem = ptr->elem;
	}
}

void EX_DICT_DEL_PAGE(EX_DICT *dict) {
	if (!dict) exit(3); // no dictionary
	if (!dict->tail) return; // no pages

	EX_DICT_PAGE *ptr;

	ptr        = dict->tail;
	dict->tail = ptr->prev;
	if (dict->tail == NULL) dict->head = NULL;

	__FREE_DICT_PAGE(ptr);

	dict->count--;
}

// INTERNAL FUNCTION DEFINITIONS

void __FREE_DICT_PAGE (EX_DICT_PAGE *page) {
	if (!page) return;

	if (page->prev) page->prev->next = page->next;
	if (page->next) page->next->prev = page->prev;

	free(page->elem);
	free(page);
}

void __FREE_DICT (EX_DICT *dict) {
	if (!dict) return;
	
	EX_DICT_PAGE *ptr;

	while (dict->tail != NULL) { // free all pages
		ptr = dict->tail;
		dict->tail = ptr->prev;
		__FREE_DICT_PAGE(ptr);
	}

	free(dict); // free the dictionary
}