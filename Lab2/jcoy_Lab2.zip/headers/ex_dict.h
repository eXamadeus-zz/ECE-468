#include <stdlib.h>

#ifndef EX_DICT_H
#define EX_DICT_H

// TYPE DEFINES

typedef struct _ex_dict {
	struct _ex_dict_page 	*head,*tail;
	int						count,cursorPos;
} EX_DICT;

typedef struct _ex_dict_page {
	struct _ex_dict_page	*prev,*next;
	unsigned char			**elem;
} EX_DICT_PAGE;

typedef struct _ex_dict_elem {

} EX_DICT_ELEM;

// FUNCTION PROTOTYPES

EX_DICT * EX_DICT_INIT();
void EX_DICT_ADD_PAGE(EX_DICT *);
void EX_DICT_DEL_PAGE(EX_DICT *);

#endif