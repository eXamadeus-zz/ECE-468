#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

void huffdecode ( FILE * encoded, FILE * decoded );
