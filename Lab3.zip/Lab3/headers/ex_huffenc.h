#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>

void huffencode ( FILE * source, FILE * encoded);
